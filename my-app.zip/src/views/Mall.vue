<template>
    <h1>我是PageOne</h1>
</template>
<script>
export default {
    data() {
        return {}
    }
}
</script>