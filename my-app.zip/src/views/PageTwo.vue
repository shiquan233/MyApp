<template>
    <h1>我是PageTwo</h1>
</template>
<script>
export default {
    data() {
        return {}
    }
}
</script>